static uint64_t crc64table[256] = {0};

static inline void generate_crc64_table()
{
	uint64_t i, j, c, crc;

	for (i = 0; i < 256; i++) {
		crc = 0;
		c = i << 56;

		for (j = 0; j < 8; j++) {
			if ((crc ^ c) & 0x8000000000000000ULL)
				crc = (crc << 1) ^ 0x42F0E1EBA9EA3693ULL;
			else
				crc <<= 1;
			c <<= 1;
		}

		crc64table[i] = crc;
	}
}
static inline void crc64(uint64_t &crc, const void *p, size_t len)
{
	size_t i, t;

	const unsigned char *_p = reinterpret_cast<const unsigned char *>(p);

	for (i = 0; i < len; i++) {
		t = ((crc >> 56) ^ (*_p++)) & 0xFF;
		crc = crc64table[t] ^ (crc << 8);
	}
}
