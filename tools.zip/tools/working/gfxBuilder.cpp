#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cstdarg>
#include <climits>
#include <limits>
#include <cmath>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <utility>
#include <random>

using namespace std;
constexpr size_t BUFFERSIZE = 16 * 1024 * 1024;
static unsigned char buffer[BUFFERSIZE];
constexpr int BANK_OFFSET = 8;

struct rgb {
  unsigned char r, g, b;
  rgb(unsigned char red, unsigned char green, unsigned char blue) :
    r{red}, g{green}, b{blue} {}
  rgb() : r{0}, g{0}, b{0} {}
  float brightness() const {
    return r * 0.30f + g * 0.59f + b * 0.11f;
  }
  bool operator<(const rgb &other) const {
    auto myBrightness = brightness();
    auto otherBrightness = other.brightness();
    if (myBrightness < otherBrightness) return true;
    if (myBrightness > otherBrightness) return false;
    return idx() < other.idx();
  }
  bool operator==(const rgb &other) const {
    return (r == other.r) && (g == other.g) && (b == other.b);
  }
  bool operator!=(const rgb &other) const {
    return !(*this == other);
  }
  int idx() const {
    return (int)b * 65536 + (int)g * 256 + (int)r;
  }
};

using palette = map<rgb, int>;

static rgb BLACK = rgb(0, 0, 0);
static rgb MAGENTA = rgb(255, 0, 255);

static inline void add_int32(vector<unsigned char> &buffer, int value)
{
  buffer.push_back((value >> 0) & 0xFF);
  buffer.push_back((value >> 8) & 0xFF);
  buffer.push_back((value >> 16) & 0xFF);
  buffer.push_back((value >> 24) & 0xFF);
}

static inline void add_int16(vector<unsigned char> &buffer, int value)
{
  buffer.push_back((value >> 0) & 0xFF);
  buffer.push_back((value >> 8) & 0xFF);
}

static inline void add_int8(vector<unsigned char> &buffer, int value)
{
  buffer.push_back((value >> 0) & 0xFF);
}

static inline void add_str(vector<unsigned char> &buffer, const string &str)
{
  for (char c : str) {
    buffer.push_back(c);
  }
}

static inline void add_str(vector<unsigned char> &buffer, const vector<unsigned char> &str)
{
  for (unsigned char c : str) {
    buffer.push_back(c);
  }
}

struct bmp {
  int w, h;
  vector<rgb> pixels;
  int cx, cy;
  
  rgb at(int x, int y) const {
    if (x < 0 || y < 0 || x >= w || y >= h) return BLACK;
    return pixels[y * w + x];
  }
  void set(int x, int y, rgb col) {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    pixels[y * w + x] = col;
  }
};

bmp CreateBMP(int width, int height)
{
  bmp img;
  img.w = width;
  img.h = height;
  img.pixels = vector<rgb>(width * height, BLACK);
  img.cx = (width - 1) / 2;
  img.cy = (height - 1) / 2;
  return img;
}


bmp LoadBMP(const char *path)
{
  FILE *fp = fopen(path, "rb");
  if (!fp) {
    fprintf(stderr, "Failed to read %s\n", path);
    exit(1);
  }
  
  fread(buffer, 1, BUFFERSIZE, fp);
  
  int offset = *( (uint32_t *)(&buffer[10]) );
  int width = *( (uint32_t *)(&buffer[18]) );
  int height = *( (uint32_t *)(&buffer[22]) );
  int bpp = *( (uint16_t *)(&buffer[28]) );
  if (bpp != 24) {
    fprintf(stderr, "%s is not a 24bpp BMP\n", path);
    fclose(fp);
    exit(1);
  }
  
  int row_stride = (width * 3 + 3) / 4 * 4;
  
  bmp img = CreateBMP(width, height);
    
  for (int y = 0; y < height; y++) {
    unsigned char *srcpos = buffer;
    srcpos += offset;
    srcpos += (height - 1 - y) * row_stride;
    
    rgb *destpos = &img.pixels[y * width];
    for (int x = 0; x < img.w; x++) {
      destpos->b = srcpos[x * 3 + 0];
      destpos->g = srcpos[x * 3 + 1];
      destpos->r = srcpos[x * 3 + 2];
      destpos++;
    }
  }

  fclose(fp);
  return img;
}
bmp CropBMP(const bmp &img, int ox, int oy, int w, int h)
{
  bmp outimg = CreateBMP(w, h);
  for (int y = 0; y < h; y++) {
    int sy = y + oy;
    for (int x = 0; x < w; x++) {
      int sx = x + ox;
      outimg.pixels[y * w + x] = img.pixels[sy * img.w + sx];
    }
  }
  return outimg;
}

void SaveBMP(bmp img, const char *path, ...)
{
  char buf[1024];
  va_list args;
  va_start(args, path);
  vsprintf(buf, path, args);
  va_end(args);
  
  FILE *fp = fopen(buf, "wb");
  if (!fp) {
    fprintf(stderr, "Failed to open %s for writing\n", buf);
    exit(1);
  }
  vector<unsigned char> data;
  
  add_str(data, "BM");
  add_int32(data, 0); // Fill in later
  add_int32(data, 0); // Reserved
  add_int32(data, 14+40); // Image data offset
  // DIB header
  add_int32(data, 40); // Header size
  add_int32(data, img.w); // Width
  add_int32(data, img.h); // Height
  add_int16(data, 1); // Colour planes
  add_int16(data, 24); // BPP
  add_int32(data, 0); // Compression method
  add_int32(data, 0); // Size (0 for uncompressed)
  add_int32(data, 0); // Hori res
  add_int32(data, 0); // Vert res
  add_int32(data, 0); // Palette
  add_int32(data, 0); // Important cols
  
  int row_stride = (img.w * 3 + 3) / 4 * 4;
  vector<unsigned char> rowdata(row_stride, 0);
  
  for (int y = img.h - 1; y >= 0; y--) { // BMPs are upside down
    const rgb *pixels = &img.pixels[y * img.w];
    for (int x = 0; x < img.w; x++) {
      rowdata[x * 3 + 0] = pixels[x].b;
      rowdata[x * 3 + 1] = pixels[x].g;
      rowdata[x * 3 + 2] = pixels[x].r;
    }
    data.insert(data.end(), rowdata.begin(), rowdata.end());
  }
  
  // Fill in size
  *((uint32_t *)&data[4]) = data.size();
  
  fwrite(data.data(), data.size(), 1, fp);
  fclose(fp);
}

void DrawBMP(bmp &target, const bmp &src, int x, int y)
{
  // Draw src to target so the centres line up. Offset by x and y
  int drawx = target.cx;
  int drawy = target.cy;
  drawx -= src.cx;
  drawy -= src.cy;
  drawx += x;
  drawy += y;
  if (drawx < 0 || drawy < 0 || drawx + src.w > target.w || drawy + src.h > target.h) {
    fprintf(stderr, "DrawBMP out of range: attempting to draw at %d,%d %d x %d to a surface of size %d x %d\n", drawx, drawy, src.w, src.h, target.w, target.h);
    exit(1);
  }
  // Draw it
  for (int y = 0; y < src.h; y++) {
    int dy = drawy + y;
    for (int x = 0; x < src.w; x++) {
      if (src.pixels[y * src.w + x] != BLACK) {
        target.pixels[dy * target.w + drawx + x] = src.pixels[y * src.w + x];
      }
    }
  }
}

void DrawBMP(bmp &target, const bmp &src, double x, double y)
{
  DrawBMP(target, src, (int) round(x), (int) round(y));
}

vector<uint16_t> loadLUT(const char *path)
{
  FILE *fp = fopen(path, "rb");
  if (!fp) {
    fprintf(stderr, "Error loading %s\n", path);
    exit(1);
  }
  vector<uint16_t> lut(256 * 256 * 256);
  fread(lut.data(), sizeof(lut[0]), lut.size(), fp);
  fclose(fp);

  return lut;
}

vector<bmp> SliceBMP(const bmp &input, int w, int h)
{
  vector<bmp> tiles;
  for (int y = 0; y < input.h; y += h) {
    for (int x = 0; x < input.w; x += w) {
      tiles.push_back(CropBMP(input, x, y, w, h));
    }
  }
  return tiles;
}

void append(vector<bmp> &appendTo, const vector<bmp> &appendWith)
{
  for (const auto &img : appendWith) {
    appendTo.push_back(img);
  }
}

bmp ComposeBMP(const vector<bmp> &tiles, int w)
{
  int h = (tiles.size() + w - 1) / w;
  int imgw = w * tiles[0].w;
  int imgh = h * tiles[0].h;
  bmp out = CreateBMP(imgw, imgh);
  out.cx = 0;
  out.cy = 0;
  int x = 0, y = 0;
  for (bmp tile : tiles) {
    tile.cx = 0;
    tile.cy = 0;
    DrawBMP(out, tile, x, y);
    x += tile.w;
    if (x >= imgw) {
      x = 0;
      y += tile.h;
    }
  }
  return out;
}

void AddColour(palette &pal, rgb pix)
{
  if (pal.count(pix)) return;
  int newIdx = pal.size();
  pal[pix] = newIdx;
}

void SortPal(palette &pal)
{
  set<rgb> s;
  for (auto p : pal) s.insert(p.first);
  vector<rgb> v;
  for (auto c : s) v.push_back(c);
  pal.clear();
  for (size_t i = 0; i < v.size(); i++) {
    pal[v[i]] = i;
  }
}

palette GetPalette(const bmp &image)
{
  palette pal;
  for (rgb pix : image.pixels) {
    AddColour(pal, pix);
  }
  SortPal(pal);
  return pal;
}

vector<palette> ReducePalettes(const vector<palette> &pals)
{
  // Remove every palette wholly included in another palette
  vector<palette> newPalettes;
  for (auto a : pals) {
    bool isRedundant = false;
    for (auto b : pals) {
      if (a == b) continue;
      set<rgb> sa, sb;
      for (auto p : a) sa.insert(p.first); 
      for (auto p : b) sb.insert(p.first); 
      if (includes(sb.begin(), sb.end(), sa.begin(), sa.end())) {
        isRedundant = true;
        break;
      }
    }
    if (!isRedundant) {
      newPalettes.push_back(a);
    }
  }
  
  // If we have two palettes that can be combined to create a <=4 col
  // palette, combine them
  restart_combining:
  for (size_t i = 0; i < newPalettes.size(); i++) {
    for (size_t j = i + 1; j < newPalettes.size(); j++) {
      palette combined;
      for (auto col : newPalettes[i]) AddColour(combined, col.first);
      for (auto col : newPalettes[j]) AddColour(combined, col.first);
      SortPal(combined);
      if (combined.size() <= 4) {
        // Combine and restart
        newPalettes.erase(newPalettes.begin() + j);
        newPalettes.erase(newPalettes.begin() + i);
        newPalettes.push_back(combined);
        goto restart_combining;
      }
    }
  }
  //fprintf(stderr, "Reduced %zu palettes down to %zu palettes\n", pals.size(), newPalettes.size());
  return newPalettes;
}

string palToStr(const palette &pal)
{
  string s;
  vector<rgb> p(pal.size());
  for (const auto &a : pal) {
    //fprintf(stderr, "%02x%02x%02x - %d\n", a.first.r, a.first.g, a.first.b, a.second);
    p[a.second] = a.first;
  }
  for (size_t i = 0; i < p.size(); i++) {
    char buf[32];
    sprintf(buf, "%02x%02x%02x", p[i].r, p[i].g, p[i].b);
    if (i > 0) s += ",";
    s += string(buf);
  }
  return s;
}

size_t GetMatchingPalette(const bmp &tile, const vector<palette> &palettes)
{
  auto tilePal = GetPalette(tile);
  //fprintf(stderr, "Searching for %s\n", palToStr(tilePal).c_str());
  for (size_t i = 0; i < palettes.size(); i++) {
    const auto &pal = palettes[i];
    //fprintf(stderr, "Checking %s\n", palToStr(pal).c_str());
    set<rgb> a, b;
    for (auto p : pal) a.insert(p.first); 
    for (auto p : tilePal) b.insert(p.first); 
    
    if (includes(a.begin(), a.end(), b.begin(), b.end())) {
      //fprintf(stderr, "Found\n");
      return i;
    }
  }
  return string::npos;
}

struct gbtile {
  uint8_t data[16];
  bool operator<(const gbtile &other) const {
    for (int i = 0; i < 16; i++) {
      if (data[i] < other.data[i]) return true;
      if (data[i] > other.data[i]) return false;
    }
    return false;
  }
  bool operator==(const gbtile &other) const {
    for (int i = 0; i < 16; i++) {
      if (data[i] != other.data[i]) return false;
    }
    return true;
  }
  bool operator!=(const gbtile &other) const {
    return !(*this == other);
  }
};

gbtile ConvertTile(const bmp &tile, const palette &pal)
{
  if (tile.w != 8 || tile.h != 8) {
    fprintf(stderr, "Not 8x8 tile\n");
    exit(1);
  }
  gbtile t;
  memset(t.data, 0, 16);
  for (int y = 0; y < 8; y++) {
    for (int x = 0; x < 8; x++) {
      rgb pix = tile.at(x, y);
      if (pal.count(pix) == 0) {
        fprintf(stderr, "Col not present in palette\n");
        exit(1);
      }
      int idx = pal.at(tile.at(x, y));
      
      t.data[y * 2 + 0] |= (idx % 2) << 7 >> x;
      t.data[y * 2 + 1] |= (idx / 2) << 7 >> x;
    }
  }
  return t;
}

struct bgmapping {
  vector<gbtile> tiles;
  vector<uint8_t> tilemap;
  vector<uint8_t> attribmap;
};

bgmapping BGMap(const vector<bmp> &tiles, const vector<palette> &palettes, int tileoffset, int paloffset)
{
  // Tile 0 is 128
  // Tile 127 is 255
  // Tile 128 is 0
  // Tile 255 is 127
  // Tile 256 is 128 bank 2
  // Tile 511 is 127 bank 2
  
  bgmapping mapping;
  vector<gbtile> gbtiles;
  vector<size_t> palmatches;
  map<gbtile, int> gbtilelut;
    
  for (const auto &tile : tiles) {
    size_t pal = GetMatchingPalette(tile, palettes);
    if (pal + paloffset > 7) {
      fprintf(stderr, "Palette index overflow\n");
      exit(1);
    }
    auto gbt = ConvertTile(tile, palettes[pal]);
    if (gbtilelut.count(gbt) == 0) {
      int newIdx = gbtilelut.size();
      gbtilelut[gbt] = newIdx;
    }
    int tileIdx = gbtilelut[gbt];
    uint8_t attrib = pal + paloffset;
    tileIdx += tileoffset;
    if (tileIdx >= 256) {
      attrib |= 8; // VRam bank
      tileIdx -= 256;
    }
    mapping.tilemap.push_back((tileIdx + 128) % 256);
    mapping.attribmap.push_back(attrib);
  }
  mapping.tiles.resize(gbtilelut.size());
  for (auto gbt : gbtilelut) {
    mapping.tiles[gbt.second] = gbt.first;
  }
  
  return mapping;
}

vector<uint16_t> gbc_lut;
bmp gbc_cols;

struct gbpalette {
  uint16_t data[4];
};
gbpalette GBPalette(const vector<rgb> &pal)
{
  gbpalette gbpal;
  int i = 0;
  for (auto p : pal) {
    gbpal.data[i] = gbc_lut[p.idx()];
    i++;
  }
    
  return gbpal;
}

struct bankentry {
  string name;
  vector<uint8_t> data;
};

struct bank {
  size_t curSize;
  vector<bankentry> entries;
};

vector<bank> banks;

void Store(const char *name, void *data, size_t sz)
{
  if (sz > 16384) {
    fprintf(stderr, "%s is too big (%zu)\n", name, sz);
    exit(1);
  }
  int b = -1;
  for (size_t i = 0; i < banks.size(); i++) {
    if (banks[i].curSize + sz < 16384) {
      b = i;
      break;
    }
  }
  if (b == -1) {
    struct bank nb;
    nb.curSize = 0;
    b = banks.size();
    banks.push_back(nb);
  }
  bankentry v;
  v.name = string(name);
  v.data.resize(sz);
  memcpy(v.data.data(), data, sz);
  banks[b].curSize += sz;
  banks[b].entries.push_back(v);
  fprintf(stderr, "Stored %s in bank %d\n", name, b + BANK_OFFSET);
  fflush(stderr);
}

const char *MESSAGE = "// This file is generated by ./gfxBuilder\n";

void WriteBanks() {
  FILE *fo_h = fopen("out/gfx/GenData.h", "w");
  fprintf(fo_h, "#pragma once\n");
  fprintf(fo_h, "%s\n", MESSAGE);
  
  for (size_t i = 0; i < banks.size(); i++) {
    char buf[256];
    sprintf(buf, "out/gfx/GenData%03zu.c", i + BANK_OFFSET);
    FILE *fo_c = fopen(buf, "w");
    fprintf(fo_c, "#pragma bank %zu\n", i + BANK_OFFSET);
    fprintf(fo_c, "%s\n", MESSAGE);
    for (auto v : banks[i].entries) {
      fprintf(fo_c, "const unsigned char GD_%s[] = {", v.name.c_str());
      for (uint8_t b : v.data) {
        fprintf(fo_c, "%d, ", b);
      }
      fprintf(fo_c, "};\n");
      fprintf(fo_h, "extern const unsigned char GD_%s[];\n", v.name.c_str());
      fprintf(fo_h, "#define GD_%s_BANK %zu\n", v.name.c_str(), i + BANK_OFFSET);
      fprintf(fo_h, "#define GD_%s_SIZE %zu\n\n", v.name.c_str(), v.data.size());
    }
    fclose(fo_c);
  }
  fclose(fo_h);
}

rgb lerp(rgb b, rgb a, double x)
{
  double new_r = a.r * x + b.r * (1.0 - x);
  double new_g = a.g * x + b.g * (1.0 - x);
  double new_b = a.b * x + b.b * (1.0 - x);
  new_r = min(max(new_r, 0.0), 255.0);
  new_g = min(max(new_g, 0.0), 255.0);
  new_b = min(max(new_b, 0.0), 255.0);
  return rgb(round(new_r), round(new_g), round(new_b));
}

vector<rgb> VecPal(palette input)
{
  vector<rgb> v(4);
  for (auto &p_entry : input) {
    v[p_entry.second] = p_entry.first;
  }
  return v;
}

int CharToFont(char c)
{
  int glyph;
  if (c == ' ') glyph = 0;
  else if (c == '\'') glyph = 1;
  else if (c >= 'A' && c <= 'Z') glyph = c - 'A' + 2;
  else if (c >= 'a' && c <= 'z') glyph = c - 'a' + 28;
  else {
    fprintf(stderr, "Unhandled char %c\n", c);
    exit(1);
  }
  return glyph;
}

vector<vector<rgb>> GenerateFades(vector<palette> input, rgb fadeto)
{
  vector<vector<rgb>> output;
  for (int i = 0; i < 16; i++) {
    double q = i / 15.0;
    for (auto p : input) {
      vector<rgb> outp(4);
      for (auto &p_entry : p) {
        auto pix = lerp(p_entry.first, fadeto, q);
        //printf("%d,%d,%d (%f) -> %d,%d,%d\n", p_entry.first.r, p_entry.first.g, p_entry.first.b, q, pix.r, pix.g, pix.b);
        outp[p_entry.second] = pix;
      }
      output.push_back(outp);
    }
  }
  
  return output;
}

bmp horizFlip(const bmp &input)
{
  bmp output = input;
  for (int y = 0; y < input.h; y++) {
    for (int x = 0; x < input.w; x++) {
      output.set(x, y, input.at(input.w - x - 1, y));
    }
  }
  return output;
}

default_random_engine rng;

int main(int argc, char **argv)
{
  auto greypal = palette();
  greypal[rgb(0, 0, 0)] = 0;
  greypal[rgb(85, 85, 85)] = 1;
  greypal[rgb(170, 170, 170)] = 2;
  greypal[rgb(255, 255, 255)] = 3;
  
  gbc_lut = loadLUT("../data/gbclut.dat");
  gbc_cols = LoadBMP("../data/gbc_cols.bmp");
  {
    vector<bmp> tiles;
    {
      auto image = LoadBMP("../data/starry.bmp");
      append(tiles, SliceBMP(image, 8, 8));
    }
    {
      auto image = LoadBMP("../maximfiles/stations.bmp");
      append(tiles, SliceBMP(image, 8, 8));
    }
    {
      vector<bmp> orbs;
      orbs = SliceBMP(LoadBMP("../maximfiles/orb0.bmp"), 16, 16);
      for (auto orb : orbs) {
        append(tiles, SliceBMP(orb, 8, 8));
      }
      orbs = SliceBMP(LoadBMP("../maximfiles/orb1.bmp"), 24, 24);
      for (auto orb : orbs) {
        append(tiles, SliceBMP(orb, 8, 8));
      }
      orbs = SliceBMP(LoadBMP("../maximfiles/orb2.bmp"), 32, 32);
      for (auto orb : orbs) {
        append(tiles, SliceBMP(orb, 8, 8));
      }
    }
    {
      auto image = LoadBMP("../data/starfont.bmp");
      append(tiles, SliceBMP(image, 8, 8));
    }
    
    {
      auto image = ComposeBMP(tiles, 16);
      SaveBMP(image, "out/gfx/spacebg.bmp");
      vector<gbtile> gbtiles;
      for (auto tile : tiles) {
        auto gbt = ConvertTile(tile, greypal);
        gbtiles.push_back(gbt);
      }
      Store("SpaceBG_c", gbtiles.data(), sizeof(gbtiles[0]) * gbtiles.size());
    }
    
    {
      auto image = LoadBMP("../data/battleui.bmp");
      auto tiles = SliceBMP(image, 8, 8);
      vector<gbtile> gbtiles;
      for (auto tile : tiles) {
        auto gbt = ConvertTile(tile, greypal);
        gbtiles.push_back(gbt);
      }
      Store("BattleUI_c", gbtiles.data(), sizeof(gbtiles[0]) * gbtiles.size());
    }
    
    {
      auto palimg = LoadBMP("../data/starpalette.bmp");
      vector<palette> pals;
      for (int i = 0; i < palimg.h; i++) {
        palette minipal;
        for (int j = 0; j < 4; j++) {
          minipal[palimg.at(j, i)] = j;
        }
        pals.push_back(minipal);
      }
      auto npals = GenerateFades(pals, rgb(255, 255, 255));
      vector<gbpalette> gbpals;
      for (auto pal : npals) gbpals.push_back(GBPalette(pal));
      Store("SpaceBG_p", gbpals.data(), sizeof(gbpals[0]) * gbpals.size());
    }
  }
  
  {
    auto image = LoadBMP("out/gfx/pshipt_rot.bmp");
    auto ships = SliceBMP(image, 512, 16);
    int shipidx = 0;
    vector<gbpalette> shipPals;
    for (auto ship : ships) {
      vector<gbtile> gbtiles;
      auto pal = GetPalette(ship);
      if (pal.size() > 4) {
        fprintf(stderr, "Ship %d has >4 cols\n", shipidx);
        exit(1);
      }
      shipPals.push_back(GBPalette(VecPal(pal)));
      
      auto shipRots = SliceBMP(ship, 16, 16);
      
      for (auto shipRot : shipRots) {
        auto tiles = SliceBMP(shipRot, 8, 8);
        for (auto tile : tiles) {
          gbtiles.push_back(ConvertTile(tile, pal));
        }
      }
      char buf[64];
      sprintf(buf, "OShip%d_c", shipidx);
      Store(buf, gbtiles.data(), sizeof(gbtiles[0]) * gbtiles.size());

      shipidx++;
    }
    Store("OShips_p", shipPals.data(), sizeof(shipPals[0]) * shipPals.size());
  }
  
  {
    auto image = LoadBMP("../maximfiles/title2.bmp");
    auto tiles = SliceBMP(image, 8, 8);
    vector<palette> pals;
    for (auto tile : tiles) {
      auto pal = GetPalette(tile);
      if (pal.size() > 4) {
        fprintf(stderr, "Title tile has >4 cols\n");
        exit(1);
      }
      pals.push_back(pal);
    }
    pals = ReducePalettes(pals);
    //for (auto p : pals) printf("- %s\n", palToStr(p).c_str());
    
    auto tileData = BGMap(tiles, pals, 0, 0);
    vector<gbpalette> gbpals;
    auto npals = GenerateFades(pals, rgb(255, 255, 255));
    for (auto pal : npals) gbpals.push_back(GBPalette(pal));
    
    Store("Title_c", tileData.tiles.data(), sizeof(tileData.tiles[0]) * tileData.tiles.size());
    Store("Title_p", gbpals.data(), sizeof(gbpals[0]) * gbpals.size());
    Store("Title_t", tileData.tilemap.data(), sizeof(tileData.tilemap[0]) * tileData.tilemap.size());
    Store("Title_a", tileData.attribmap.data(), sizeof(tileData.attribmap[0]) * tileData.attribmap.size());
  }
  
  printf("\n");
  
  vector<uint16_t> sincos;
  
  //printf("cos = { ");
  // Cos table
  
  for (int mul = 4; mul <= 18; mul += 2) { // 4 6 8 10 12 14 16 18
    for (int i = 0; i < 256; i++) {
      int val = round(cos((i + 64) * 3.14159265358979323846264338327950288 * 2.0 / 256.0) * mul);
      val *= -1;
      if (val < 0) val += 65536;
      sincos.push_back(val);
      //printf("%d, ", val);
    }
    //printf("}\nsin = { ");
    for (int i = 0; i < 256; i++) {
      int val = round(sin((i + 64) * 3.14159265358979323846264338327950288 * 2.0 / 256.0) * mul);
      val *= -1;
      if (val < 0) val += 65536;
      sincos.push_back(val);
      //printf("%d, ", val);
    }
    
  }
  //printf("}\n");
  Store("SinCos", sincos.data(), sizeof(sincos[0]) * sincos.size());
  
  // Starry sky
  {
    uniform_int_distribution<int> dist(0, 255);
    
    vector<uint8_t> starry_sky( 128 * 128 );
    for (int y = 0; y < 128; y++) {
      for (int x = 0; x < 128; x++) {
        uint8_t &c = starry_sky[y * 128 + x];
        int r = dist(rng);
        r -= 216;
        if (r > 0) {
          c = 128 + r;
        } else {
          c = 128;
        }
        
        if (x >= 72 || y >= 71) c = starry_sky[(y % 71) * 128 + (x % 72)];
      }
    }
    /*
    for (int i = 0; i < 128; i++) {
      starry_sky[0 * 128 + i] = 128 + 36;
      starry_sky[71 * 128 + i] = 128 + 36;
      starry_sky[i * 128 + 0] = 128 + 36;
      starry_sky[i * 128 + 72] = 128 + 36;
    }
    */
    
    Store("StarrySky", starry_sky.data(), sizeof(starry_sky[0]) * starry_sky.size());
  }
  
  vector<int> systempalette(64);
  vector<string> systemname(64);
  // Planets time
  {
    vector<uint8_t> planetdata;
    
    uniform_int_distribution<int> dist(0, 255);
    uniform_int_distribution<int> bodies_dist(2, 8);
    uniform_int_distribution<int> x_dist(20 / 4, 68 / 4);
    uniform_int_distribution<int> y_dist(20 / 4, 64 / 4);
    uniform_int_distribution<int> sz_dist(0, 2);
    uniform_int_distribution<int> col_dist(1, 6);
    uniform_int_distribution<int> stationchance_dist(0, 2);
    uniform_int_distribution<int> xy_dist(0, 3);
    uniform_int_distribution<int> station_dist(43, 58);
    uniform_int_distribution<int> solarx_dist(0, 35);
    uniform_int_distribution<int> solary_dist(0, 38);
    // Stations: 43
    // 2x2: 59
    // 3x3: 
    const int sz_pos[] = {59, 107, 224};
    const int sz_count[] = {12, 13, 11};
        
    for (int solar = 0; solar < 64; solar++) {
      int solarx = solarx_dist(rng);
      int solary = solary_dist(rng);
      int mem_loc = solary * 128 + solarx + 0x4000;
      planetdata.push_back(mem_loc % 256);
      planetdata.push_back(mem_loc / 256);
      
      size_t slotdata_idx = planetdata.size();
      for (int i = 0; i < 32; i++) {
        planetdata.push_back(0);
      }
      int body_count = bodies_dist(rng);
      vector<int> slots(16, 0);
      multimap<double, int> sortedslots;
      map<int, size_t> slot_to_location;
      
      for (int body_num = 1; body_num <= body_count; body_num++) {
        int x, y, my_slot;
        for (;;) {
          x = x_dist(rng);
          y = y_dist(rng);
          my_slot = (y % 4) * 4 + (x % 4);
          if (slots[my_slot] == 0) break;
        }
        slots[my_slot] = body_num;
        
        int sz = sz_dist(rng);
        uniform_int_distribution<int> idx_dist(1, sz_count[sz] - 1);
        int idx = idx_dist(rng);
        int idx2 = idx_dist(rng);
        idx = min(idx, idx2);
        
        uniform_int_distribution<int> offset_dist(0, 2 - sz);
        int planet_x_offset = offset_dist(rng);
        int planet_y_offset = offset_dist(rng);
        int planet_x = x * 4 + planet_x_offset;
        int planet_y = y * 4 + planet_y_offset;
        
        vector<int> chrs_taken(16, 0);
        for (int cy = 0; cy < sz + 2; cy++) {
          for (int cx = 0; cx < sz + 2; cx++) {
            chrs_taken[(cy + planet_y_offset) * 4 + (cx + planet_x_offset)] = 1;
          }
        }
        
        int station_x = -1;
        int station_y = -1;
        
        if (sz < 2) {
          if (stationchance_dist(rng) == 0) {
            for (;;) {
              int cx = xy_dist(rng);
              int cy = xy_dist(rng);
              if (chrs_taken[cy * 4 + cx] == 0) {
                station_x = x * 4 + cx;
                station_y = y * 4 + cy;
                break;
              }
            }
          }
        }
        
        double dist_x = (planet_x + (sz + 2) * 0.5) - 46.0;
        double dist_y = (planet_y + (sz + 2) * 0.5) - 44.5;
        double dist = dist_x * dist_x + dist_y * dist_y;
        
        sortedslots.insert(make_pair(dist, my_slot));
        int char_pos = sz_pos[sz] + idx * (sz + 2) * (sz + 2);
        int vram_bank = 0;
        if (char_pos >= 256) {
          vram_bank = 1;
          char_pos -= 256;
        }
        char_pos = (char_pos + 128) % 256;
        
        slot_to_location[my_slot] = planetdata.size();
        planetdata.push_back(planet_x);
        planetdata.push_back(planet_y);
        planetdata.push_back(sz + 2);
        planetdata.push_back(vram_bank * 8 + col_dist(rng));
        //printf("In system %d the body with dist %f has palette %d\n", solar, dist, planetdata[planetdata.size()-1] & 7);
        planetdata.push_back(char_pos);
        if (station_x == -1) {
          planetdata.push_back(0);
          planetdata.push_back(0);
          planetdata.push_back(0);
        } else {
          planetdata.push_back(station_x);
          planetdata.push_back(station_y);
          planetdata.push_back(station_dist(rng) + 128);
        }
      }
      for (int i = body_count + 1; i <= 8; i++) {
        planetdata.push_back(0);
        planetdata.push_back(0);
        planetdata.push_back(0);
        planetdata.push_back(0);
        planetdata.push_back(0);
        
        planetdata.push_back(0);
        planetdata.push_back(0);
        planetdata.push_back(0);
      }
      
      int body_from_origin = 1;
      for (auto sortedslot : sortedslots) {
        planetdata[slotdata_idx + sortedslot.second + 0] = body_from_origin;
        if (slot_to_location.count(sortedslot.second) == 0) {
          fprintf(stderr, "Failed to find slot %d\n", sortedslot.second);
          exit(1);
        }
        size_t star_loc = slot_to_location[sortedslot.second];
        planetdata[slotdata_idx + sortedslot.second + 16] = (star_loc - slotdata_idx - 32) / 8;
        
        if (body_from_origin == 1) {
          // 1 is always the star
          
          int star_sz = planetdata[star_loc + 2] - 2;
          
          // Store its palette
          systempalette[solar] = planetdata[star_loc + 3] & 7;
          
          // Change its graphic
          int star_gfx = sz_pos[star_sz];
          int star_vram = 0;
          if (star_gfx >= 256) {
            star_vram = 1;
            star_gfx -= 256;
          }
          planetdata[star_loc + 3] = star_vram * 8 + col_dist(rng);
          planetdata[star_loc + 4] = (star_gfx + 128) % 256;
          
          // Can't have a station
          planetdata[star_loc + 5] = 0;
          planetdata[star_loc + 6] = 0;
          planetdata[star_loc + 7] = 0;
        }
        body_from_origin++;
      }
      
    }
    
    Store("SolarSystem", planetdata.data(), sizeof(planetdata[0]) * planetdata.size());
  }
  
  {
    vector<string> starNames = {"Acemoglu", "Aegina", "Aelba", "Aheramori", "Albizia", "Alnaid", "Alpa", "Anbethia", "Anshar", "Beccer", "Blue Methuselah", "Carguillo", "Carrache", "Cavan", "Charm", "Dolich", "Ella Nautilus", "Emporia", "En Faidherbia", "Equinox", "Fell", "Florence", "Garcia's Star", "Gevelgerin", "Giada", "Gloriosa", "Grimaldi", "Gross", "Gursum", "Hijuri", "Holms", "Hosseini", "Ipyune", "Ken", "La Morella", "Lammas", "Landsberg", "Lat", "Leukonoides", "Mami", "Manicula", "Manitou", "Meriden", "Mizzimau", "Moonglow", "Myke", "Pollio", "Raddus", "Raechelle", "Revelation", "Sanelime", "Sideris", "Somair", "Sotere", "Spar", "Tamino", "Tarit", "Telome", "Thon", "Vahlia", "Valas", "Van", "Wendigo", "Xal", "Xena", "Yaf"};
    vector<string> romanNums = {"I", "II", "III", "IV", "V", "VI", "VII"};
    uniform_int_distribution<size_t> sn_dist(0, starNames.size() - 1);
    set<size_t> used_idxes;
    vector<uint8_t> planetNameData;
    for (int solar = 0; solar < 64; solar++) {
      size_t starname_idx;
      for (;;) {
        starname_idx = sn_dist(rng);
        if (used_idxes.count(starname_idx) == 0) break;
      }
      used_idxes.insert(starname_idx);
      string starname = starNames[starname_idx];
      systemname[solar] = starname;
      vector<string> bodynames;
      bodynames.push_back(starname);
      for (int body = 0; body < 7; body++) {
        bodynames.push_back(starname + " " + romanNums[body]);
      }
      
      for (string n : bodynames) {
        while (n.size() < 20) {
          n = string(" ") + n + string(" ");
        }
        if (n.size() > 20) n = n.substr(0, 20);
        n += "            ";
        
        for (char c : n) {
          int glyph = CharToFont(c);
          glyph += 400; // 400 - 453
          glyph -= 256;
          glyph = (glyph + 128) % 256;
          planetNameData.push_back(glyph);
        }
      }
    }
    Store("PlanetNames", planetNameData.data(), sizeof(planetNameData[0]) * planetNameData.size());
  }
  {
    vector<uint8_t> solarxy;
    vector<uint8_t> galaxymap(20 * 18, 128);
    vector<uint8_t> galaxyattrs(20 * 18, 0);
    vector<uint8_t> galaxyidx(20 * 18, 255);
    uniform_int_distribution<size_t> x_dist(0, 19);
    uniform_int_distribution<size_t> y_dist(1, 16);
    uniform_int_distribution<size_t> pl_dist(40, 42);
    for (int solar = 0; solar < 64; solar++) {
      int x, y;
      for (;;) {
        x = x_dist(rng);
        y = y_dist(rng);
        if (galaxymap[y * 20 + x] != 128) continue;
        if (x > 0 && galaxymap[y * 20 + (x - 1)] != 128) continue;
        if (y > 1 && galaxymap[(y - 1) * 20 + x] != 128) continue;
        if (y < 16 && galaxymap[(y + 1) * 20 + x] != 128) continue;
        if (x < 19 && galaxymap[y * 20 + (x + 1)] != 128) continue;
        break;
      }
      galaxymap[y * 20 + x] = pl_dist(rng) + 128;
      galaxyattrs[y * 20 + x] = systempalette[solar];
      galaxyidx[y * 20 + x] = solar;
      solarxy.push_back(x);
      solarxy.push_back(y);
    }
    
    string n = "    Galactic Map    ";
    {
      int x = 0;
      for (char c : n) {
        int glyph = CharToFont(c);
        glyph += 400; // 400 - 453
        glyph -= 256;
        glyph = (glyph + 128) % 256;
        galaxymap[x] = glyph;
        galaxyattrs[x] = 8 + 7;
        galaxymap[17 * 20 + x] = 16;
        galaxyattrs[17 * 20 + x] = 8 + 7;
        x++;
      }
    }
    
    Store("SolarXY", solarxy.data(), sizeof(solarxy[0]) * solarxy.size());
    Store("Galaxy_t", galaxymap.data(), sizeof(galaxymap[0]) * galaxymap.size());
    Store("Galaxy_a", galaxyattrs.data(), sizeof(galaxyattrs[0]) * galaxyattrs.size());
    Store("Galaxy_i", galaxyidx.data(), sizeof(galaxyidx[0]) * galaxyidx.size());
  }
  
  for (int i = 0; i < 64; i++) {
    printf("System %d is %s and has palette %d\n", i, systemname[i].c_str(), systempalette[i]);
  }
  
  {
    vector<string> shipFiles = {"pship0", "pship1", "pship2", "ship0", "ship1", "ship2", "ship3", "ship4", "ship5", "ship6", "ship7", "ship8", "ship9", "ship10", "ship11", "ship12", "ship13", "ship14", "ship15", "ship16", "ship17", "ship18", "ship19"};
  const int laserData[][20] = {{34, 40, 46, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 51, 0, 0},
    {31, 12, 15, 18, 23, 60, 15, 67, 0, 0, 0, 0, 0, 0, 0, 0, 15, 51, 0, 0},
    {19, 1, 2, 7, 13, 13, 1, 19, 4, 40, 0, 46, 0, 66, 0, 0, 53, 28, 0, 75},
    {65, 30, 71, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {69, 35, 65, 43, 63, 51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {67, 29, 71, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {67, 27, 41, 35, 55, 52, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {54, 18, 59, 22, 55, 40, 52, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {57, 6, 51, 41, 47, 45, 71, 72, 0, 0, 0, 0, 0, 0, 0, 0, 55, 27, 0, 0},
    {57, 14, 55, 35, 47, 39, 55, 43, 57, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {70, 30, 66, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 43, 0, 0},
    {57, 17, 47, 54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 27, 0, 0},
    {88, 21, 35, 36, 43, 50, 24, 54, 0, 0, 0, 0, 0, 0, 0, 0, 15, 42, 0, 0},
    {44, 22, 71, 26, 23, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 71, 53, 0, 0},
    {16, 1, 62, 10, 62, 15, 62, 20, 2, 28, 16, 35, 16, 40, 0, 0, 7, 75, 0, 0},
    {23, 4, 7, 10, 37, 17, 55, 22, 57, 73, 0, 0, 0, 0, 0, 0, 23, 51, 15, 59},
    {17, 29, 17, 35, 15, 58, 17, 64, 7, 72, 0, 0, 0, 0, 0, 0, 39, 20, 31, 12},
    {40, 5, 27, 13, 18, 18, 23, 23, 16, 49, 23, 72, 0, 0, 0, 0, 31, 59, 0, 0},
    {53, 23, 41, 28, 17, 44, 15, 52, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {37, 29, 27, 50, 36, 54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 45, 0, 0},
    {47, 30, 43, 41, 52, 51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {14, 12, 22, 18, 7, 23, 3, 31, 0, 58, 2, 68, 16, 74, 0, 0, 0, 51, 0, 0},
    {56, 33, 55, 37, 55, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
    
    bgmapping allships_mapping;
    vector<gbpalette> gbpals;
    vector<uint8_t> shipData;
    vector<uint8_t> blackTileData;
    
    for (size_t shipidx = 0; shipidx < shipFiles.size(); shipidx++) {
      string shipPath = "../maximfiles/" + shipFiles[shipidx] + ".bmp";
      auto image = LoadBMP(shipPath.c_str());
      
      bgmapping this_mapping;
      
      for (int flip = 0; flip < 2; flip++) {
        if (flip == 1) {
          image = horizFlip(image);
        }
        
        for (int i = 0; i < 10; i++) {
          int x = laserData[shipidx][i * 2 + 0];
          int y = laserData[shipidx][i * 2 + 1];
          shipData.push_back(flip ? 159 - x : x);
          shipData.push_back(y);
        }
        for (int i = 0; i < 12; i++) { // pad to 32 bytes each
          shipData.push_back(0);
        }
        
        auto tiles = SliceBMP(image, 8, 8);
        vector<palette> pals;
        int tileidx = 0;
        for (auto tile : tiles) {
          //if (flip) tile = horizFlip(tile);
          auto pal = GetPalette(tile);
          if (pal.size() > 4) {
            fprintf(stderr, "Tile @ %d,%d in ship %s has >4 cols\n", (tileidx % 20) * 8, (tileidx / 20) * 8, shipFiles[shipidx].c_str());
            exit(1);
          }
          pals.push_back(pal);
          tileidx++;
        }
        pals = ReducePalettes(pals);
        
        auto tileData = BGMap(tiles, pals, flip ? 128 : 0, flip ? 4 : 0);
        if (flip == 0) {
          bmp blackTile = CreateBMP(8, 8);
          size_t blackTilePal = GetMatchingPalette(blackTile, pals);
          size_t blackTileIdx = 0;
          auto gbt = ConvertTile(blackTile, pals[blackTilePal]);
          for (size_t i = 0; i < tileData.tiles.size(); i++) {
            if (tileData.tiles[i] == gbt) {
              blackTileIdx = i;
              break;
            }
          }
          blackTileIdx = (blackTileIdx + 128) % 256;
          blackTileData.push_back(blackTilePal);
          blackTileData.push_back(blackTileIdx);
        }
        
        while (pals.size() < 4) {
          pals.push_back(greypal);
        }
        for (auto pal : pals) {
          gbpals.push_back(GBPalette(VecPal(pal)));
        }
        gbtile blank;
        memset(blank.data, 0, 16);
        while (tileData.tiles.size() < 128) {
          tileData.tiles.push_back(blank);
        }
        /*
        for (uint8_t &attrib : tileData.attribmap)
        {
          attrib |= 32;
        }
        */
        
        this_mapping.tiles.insert(this_mapping.tiles.end(), tileData.tiles.begin(), tileData.tiles.end());
        allships_mapping.tilemap.insert(allships_mapping.tilemap.end(), tileData.tilemap.begin(), tileData.tilemap.end());
        allships_mapping.attribmap.insert(allships_mapping.attribmap.end(), tileData.attribmap.begin(), tileData.attribmap.end());
        
      /*   vector<gbtile> tiles;
  vector<uint8_t> tilemap;
  vector<uint8_t> attribmap; */
      
        printf("%s - %zu palettes, %zu tiles\n", shipFiles[shipidx].c_str(), pals.size(), tileData.tiles.size());
      }
      Store((string("Ships_") + shipFiles[shipidx] + "_c").c_str(), this_mapping.tiles.data(), sizeof(this_mapping.tiles[0]) * this_mapping.tiles.size());
    }
    
    Store("Ships_p", gbpals.data(), sizeof(gbpals[0]) * gbpals.size());
    Store("Ships_t", allships_mapping.tilemap.data(), sizeof(allships_mapping.tilemap[0]) * allships_mapping.tilemap.size());
    Store("Ships_a", allships_mapping.attribmap.data(), sizeof(allships_mapping.attribmap[0]) * allships_mapping.attribmap.size());
    Store("Ships_d", shipData.data(), sizeof(shipData[0]) * shipData.size());
    Store("Ships_bt", blackTileData.data(), sizeof(blackTileData[0]) * blackTileData.size());
  }
  
  WriteBanks();
}
