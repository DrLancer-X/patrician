This is GBSoundSystem, an MIT-licensed playback library
for music created by the P5 Tracker
https://github.com/gb-archive/GBSoundSystem/
It must be assembled and linked with rgbds, then the library
can be extracted for use in gbdk with ./extractSoundSystem

rgbasm.exe -o SoundSystem.obj SoundSystem.asm
rgbasm.exe -o SoundSystemAddresses.obj SoundSystemAddresses.asm
rgblink.exe -o SoundSystem.gb SoundSystem.obj SoundSystemAddresses.obj
